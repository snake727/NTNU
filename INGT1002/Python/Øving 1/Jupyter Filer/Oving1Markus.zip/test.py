import numpy

def f(x):
    return 2 * x + 1

def g(x):
    return (-4 * x + 2)/(5 * x + 3)

def h(x):
    return (x ** 2) + 2 * x + 1

def i(x):
    return numpy.roots(x) #Eller så kan man bruke 

def j(x):
    return numpy.sin(x) + numpy.cos(x)

print(i(25))